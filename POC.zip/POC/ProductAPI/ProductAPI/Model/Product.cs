﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProductAPI.Model
{
    [Table(name: "Product")]
    public class Product
    {
        [Key]
        [Column(TypeName = "Int")]
        public int ProductId { get; set; }

        [Column(TypeName = "Varchar(20)")]
        public string? ProductName { get; set; }

        [Column(TypeName = "Varchar(20)")]
        public int ProductPrice { get; set; }

    }
}
