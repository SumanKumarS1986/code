﻿using Microsoft.AspNetCore.Mvc;
using ProductAPI.DataAccess;
using ProductAPI.Model;
using System.Collections.Generic;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProductAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {

        private readonly DataContext _dataContext;
        public ProductController(DataContext DataContext)
        {
            _dataContext = DataContext;
        }
        // GET: api/<ProductController>
        [HttpGet]
        public IEnumerable<Product> Get()
        {
            return _dataContext.Products;
        }

        // GET api/<ProductController>/5
        [HttpGet("{id}")]
        public Product Get(int id)
        {
            return _dataContext.Products.SingleOrDefault(x=>x.ProductId == id);
        }

        // POST api/<ProductController>
        [HttpPost]
        public void Post([FromBody] Product product)
        {
            _dataContext.Products.Add(product);
            _dataContext.SaveChanges();
        }

        // PUT api/<ProductController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Product product)
        {
            _dataContext.Products.Update(product);
            _dataContext.SaveChanges();
        }

        // DELETE api/<ProductController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            var productId = _dataContext.Products.SingleOrDefault(x => x.ProductId == id);
            if (productId != null)
            {
                _dataContext.Products.Remove(productId);
                _dataContext.SaveChanges();
            }
        }
    }
}
