import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { Products, ProductService } from '../product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  ProductList: Observable<Products[]>;
  productForm: any;
  message = '';
  prodCategory = '';
  isEdit = false;
  
  constructor(private formbulider: FormBuilder, private productService: ProductService) { }
 
  ngOnInit() {
    
    this.productForm = this.formbulider.group({
      productId: ['', [Validators.required]],
      productName: ['', [Validators.required]],
      productPrice: ['', [Validators.required]],
    });
    this.getProductList();
  }
 
  getProductList() {
    this.ProductList = this.productService.getProductList();
  }
 
  PostProduct() {
    debugger;
    const product_Master = this.productForm.value;
    this.productService.postProductData(product_Master).subscribe(
      () => {
        this.message = 'Data Saved Successfully';
        this.getProductList();
        this.productForm.reset();
      }
    );
  }
 
  ProductDetailsToEdit(id: string) {
    debugger;
    this.isEdit = true;
    this.productService.getProductDetailsById(id).subscribe(productResult => {
      this.productForm.controls['productId'].setValue(productResult.productId);
      this.productForm.controls['productName'].setValue(productResult.productName);
      this.productForm.controls['productPrice'].setValue(productResult.productPrice);
    });
 
  }
 
  UpdateProduct() {
    debugger;
    const product_Master = this.productForm.value;
    this.productService.updateProduct(product_Master).subscribe(() => {
      this.message = 'Record Updated Successfully';
      this.getProductList();
      this.isEdit = false;
      this.productForm.reset();
    });
  }
 
  DeleteProduct(id: string) {
    //if (confirm('Do you want to delete this product?')) {
      this.productService.deleteProductById(id).subscribe(() => {
        this.getProductList();
        this.message = 'Record Deleted Successfully';
      });
    //}
  }
}
