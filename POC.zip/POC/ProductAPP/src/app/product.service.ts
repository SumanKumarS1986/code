import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { environment } from '../environments/environment'
@Injectable({
  providedIn: 'root'
})

export class ProductService {
  debugger;
  url = environment.apiurl;
  httpHeaders = { headers:new HttpHeaders({'Content-Type': 'application/json'}) };
    constructor(private http: HttpClient) { }
   
    getProductList(): Observable<Products[]> {
      return this.http.get<Products[]>(this.url + '/Product');
    }

    getProductDetailsById(id: string): Observable<Products> {
      return this.http.get<Products>(this.url + '/Product/' + id);
    }
   
    postProductData(productData: Products): Observable<Products> {
      return this.http.post<Products>(this.url + '/Product/', productData, this.httpHeaders);
    }
   
    updateProduct(productData: Products): Observable<Products> {
      return this.http.put<Products>(this.url + '/Product/' + productData.productId, productData, this.httpHeaders);
    }
    deleteProductById(id: string){
      return this.http.delete<number>(this.url + '/Product/' + id, this.httpHeaders);
    }

    // getProductList() {
    //   return this.http.get<Products[]>(this.url + '/Product');
    // }
   
    // postProductData(productData: Products) {
    //   const httpHeaders = { headers:new HttpHeaders({'Content-Type': 'application/json'}) };
    //   return this.http.post<Products>(this.url + '/Product/', productData, httpHeaders);
    // }
   
    // updateProduct(productData: Products) {
    //   const httpHeaders = { headers:new HttpHeaders({'Content-Type': 'application/json'}) };
    //   return this.http.put<Products>(this.url + '/Product/' + productData.productId, productData, httpHeaders);
    // }
    // deleteProductById(id: string) {
    //   const httpHeaders = { headers:new HttpHeaders({'Content-Type': 'application/json'}) };
    //   return this.http.delete<number>(this.url + '/Product/' + id, httpHeaders);
    // }
   
    // getProductDetailsById(id: string) {
    //   return this.http.get<Products>(this.url + '/Product/' + id);
    // }
  
}
export class Products {
  productId: string;
  productName: string;
  productPrice: string;
}
